import DocumentionPage from '@/components/doc/DocumentionPage';
import PageHeader from '@/components/PageHeader';
import React from 'react';
import { Container, Button, Row } from 'react-bootstrap';

const Documention = () => {
  return (
    <>
     <DocumentionPage />
    </>

  );
};

export default Documention;
