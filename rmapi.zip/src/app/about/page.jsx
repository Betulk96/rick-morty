import AboutPage from '@/components/about/AboutPage';
import React from 'react';
import { Container } from 'react-bootstrap';

const About = () => {
  return (
    <>

      <AboutPage />
   
    </>
  );
}

export default About;
