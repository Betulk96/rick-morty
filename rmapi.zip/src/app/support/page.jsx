import SupportPage from '@/components/support/SupportPage'
import React from 'react'

const Support = () => {
  return (
    <>
    <SupportPage />   
    </>
  )
}

export default Support
