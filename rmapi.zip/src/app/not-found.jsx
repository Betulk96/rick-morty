
import NotFound from "@/components/errors/not-found";
import Spacer from "@/components/Spacer";

import React from "react";

const NotFoundPage = () => {

	return (
		<>			
			<NotFound />
			
		</>
	);
};

export default NotFoundPage;
